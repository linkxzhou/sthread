#include "gtest/googletest/include/gtest/gtest.h"
#include "../include/mt_session.h"

MTHREAD_NAMESPACE_USING

TEST(SessionTest, session)
{
	
}

// 测试所有的功能
int main(int argc, char* argv[])
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}